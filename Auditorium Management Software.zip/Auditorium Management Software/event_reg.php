<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="event.css">
<style>
	body
	{
		text-align:center;
		background-image:url('audit.jpg');
        background-repeat:no-repeat;
        background-attachment:fixed;
         background-size: 100% 100%;
	}
</style>
</head>
<body>
	<div class="wrapper">
		<h2 class="header">Event Registration Form</h2>
<form method="post" action="reg_suc.html">
	<label for="name">Name</label>
	<input type="text" name="username" id="name" required><br>
	
	<label for="eventNames">Events</label>
	<select name="eventNames">
		<option value="one">Book Launching Ceremony</option>
		<option value="two">Pavithra Bhat's Bharatanatyam</option>
		<option value="three">StandUp Comedy by Viva Harsha</option>
		<option value="four">Robin Sharma's Speech</option>
		<option value="five">Music Concert By Shreya Goshal</option>
		<option value="five">Cheer Your Favourite Sports Team On!</option>
		<option value="six">Magic Show By Christopher</option>
		<option value="seven">Dance show by BTS</option>
		<option value="eight">TEDx Event</option>
		<option value="nine">Meet Da Vinci</option>
		<option value="ten">Piano Concert By Sizuka</option>
		<option value="eleven">Maroon 5 Concert</option>
		<option value="twelve">Personl Finance By Robert Kiyosaki</option>
		<option value="thirteen">A Talk on Entreprenuership By ElonMusk</option>
		
	</select><br>
	<label for="Time">Timings</label>
	<select name="country" id="country">
		<option value="one">9:00AM to 11:00AM</option>
		<option value="two">11:00AM to 12:00PM</option>
		<option value="three">2:00PM to 3:00PM</option>
		<option value="four">3:00PM to 4:00PM</option>
	</select>
	<div class="button">
		 <a href="reg_suc.html" >
		 	<input type="submit" value="Submit" name="" class="btn">
		 	
		 </a>
        <!-- <input type="submit"  value="Submit" class="btn" style="margin-left:30px;"></div> -->
                
	</div>
</form>
</div>

<!-- <?php
if(isset($_POST["submit"]))
{
 
 //Including config file.
include 'config.php';
 
$eventName=$_POST["eventNames"];

mysql_query("INSERT INTO events (event) VALUES ('$eventName')"); 

echo " Added Successfully ";

}

 ?> -->


</body>
</html>
