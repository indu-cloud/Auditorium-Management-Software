<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>SpotLight Events</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
<body>


<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">SpotLight Events</a></h1>
      <h2>Make Your Event Beautiful</h2>
    </div>
    <nav>
      <ul>
        <li><a href="index.php?variableName=.">Home</a></li>
        <li><a href="events.php?variableName=.">Events</a></li>
        <li><a href="login.php?variableName=.">Login</a></li>
        <li><a href="register.php?variableName=.">Register</a>

</li>
        <li class="last"><a href="aboutus.php?variableName=.">About Us</a></li>
      </ul>
    </nav>
  </header>
</div>
<!-- content -->
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- Slider -->
    <section id="slider" class="clear">
      <figure><img src="images/audit.jpg" alt="">
        <figcaption>
          <h3>SpotLight Event Managers</h3>
          <p>As we event management specialists in Vizag, India. We are the Professional event management architects We offer streamlined events to suit your objectives,We provide an corporate event management services that are fabulously planned and remembered always. Behind every project, highly qualified people are here to help with all their talents.</p>
          <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
        </figcaption>
      </figure>
    </section>
    <!-- main content -->
    <div id="homepage">
      <!-- services area -->
      <section id="services" class="clear">
		 <h2>latest Events</h2>
		 <br>
		 <br>
        <!-- article 1 -->
        <article class="one_third">
          <h2>Book Launching ceremony</h2>
          <img src="images/book.png" alt="">
          <p>A book launching ceremony for the book written by one of the former commanders of the Navy, Admiral (Retd) Dr. Jayantha Colombage RSP VSV usp reds psc PhD on “Asymmetric Warfare at Sea” was held at 0900 am on 08th December 2016 at General Sir John Kotelawala Defence University. Admiral (Retd) Dr. Jayantha Colombage is the first ever PhD degree holder produced by KDU, and the above book is based on his PhD thesis.Senior Professor Carlo Fonseka, president of the Sri Lanka Medical Council graced the occasion as the Chief Guest; many distinguished guests and the senior officers of Tri Services also participated in this event.</p>
          <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
        </article>
        <!-- article 2 -->
        <article class="one_third">
          <h2>Pavithra Bhat's Bharatanatyam</h2>
          <img src="images/barat1.jpg" alt="">
          <p>Pavitra Bhat (Bharatanatyam)Catch the extremely dynamic and phenomenal Bharatanatyam young maestro Pavitra Bhat take the stage on fire with his poise and abhinaya coupled with top-notch skills on his feet, posture and hands. Kalasagar awards are given in honour of the artistes in the field of Kathakali - Vesham, Music, Chenda, Maddalam and Chutty as well as Bharatanatyam, Mohiniattam, Kuchipudi, Ottenthullal, Chakyarkoothu Vesham, Music, Chenda, Maddalam and Chutty as well as Bharatanatyam, Mohiniattam, Kuchipudi, Ottenthullal, Chakyarkoothu</p>
          <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
        </article>
        <!-- article 3 -->
        <article class="one_third lastbox">
          <h2>StandUp Comedy by Viva Harsha</h2>
          <img src="images/harsha.jpg" alt="">
          <p>Who doesn't enjoy a good laugh? You'll find the latest shows by the best Indian comedians - Zakir Khan, Kanan Gill, Biswa Kalyan Rath, Kenny Sebastian, Comicstaan finalists (Nishant Suri, Rahul Dua & others) and more, on Paytm Insider. Catch them doing tours of their specials, trying new material, hosting an open mic, and more. Catch the big names of comedy at Headliners and LOLStars; or shows to see up-and-coming comics enthrall audiences, and open mic events where you'll see and cheer on fresh talent! International legends like Russel Peters, Eddie Izzard & Bill Burr have ticketed here in the past.</p>
          <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
        </article>
      </section>
      <!-- / services area -->
      <!-- ########################################################################################## -->
      <!-- ########################################################################################## -->
      <!-- ########################################################################################## -->
      <!-- ########################################################################################## -->
      <!-- One Quarter -->
      <h2>More Events</h2> 
      <br>
      <br>
      <section id="latest" class="last clear">
        <article class="one_quarter">
          <figure><img src="images/robin.png" width="215" height="140" alt="">
            <figcaption>
              <h2>Robin Sharma's Speech</h2>
              <p>Robin Sharma is a Canadian writer, best known for his The Monk Who Sold His Ferrari book series. Sharma worked as a litigation lawyer until age 25, when he self-published MegaLiving, a book on stress management and spirituality</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter">
          <figure><img src="images/shreya.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>Music Concert By Shreya Goshal</h2>
              <p>Shreya Ghoshal is an Indian playback singer, songwriter, composer and music producer. She has received four National Film Awards, four Kerala State Film Awards, two Tamil Nadu State Film Awards, seven Filmfare Awards and ten Filmfare Awards South</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter">
          <figure><img src="images/sunrisers.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>Cheer Your Favourite Sports Team On!</h2>
              <p> Fans are the most important part of IPL and every year they bring many innovations to uplift their team. Get a chance to meet your favorite team.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter lastbox">
          <figure><img src="images/magic.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>Magic Show By Christopher</h2>
              <p>Magic is a mixture of art, science and illusion. It is an art of amazing people which not merely entertainment.Everyone enjoys magic show.Get ready for the mere experience.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
      </section>
      <br>
      <section id="latest" class="last clear">
        <article class="one_quarter">
          <figure><img src="images/bts.png" width="215" height="140" alt="">
            <figcaption>
              <h2>Dance show by BTS</h2>
              <p>Nullamlacus dui ipsum conseque loborttis non euisque morbi penas dapibulum orna.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter">
          <figure><img src="images/beatbox.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>Beat Box Performance</h2>
              <p>BTS, also known as the Bangtan Boys, is a seven-member South Korean boy band that began formation in 2010 and debuted in 2013 under Big Hit Entertainment.Get ready to meet them</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter">
          <figure><img src="images/tedx.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>TEDx Event</h2>
              <p>TED Conferences LLC is an American media organization that posts talks online for free distribution under the slogan "ideas worth spreading".</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter lastbox">
          <figure><img src="images/vinci.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>meet da vinci</h2>
              <p>Leonardo da Vinci,one of the greatest artists of all time, he is well known for his two remarkable paintings: The Mona Lisa and The Last Supper.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
      </section>
      <br>
      <section id="latest" class="last clear">
        <article class="one_quarter">
          <figure><img src="images/piano.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>piano concert by sizuka</h2>
              <p>a solo composition in the classical music genre which is composed for a piano player, which is typically accompanied by an orchestra or other large ensemble.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter">
          <figure><img src="images/marron.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>marron 5 music concert</h2>
              <p>Maroon 5 is an American pop rock band from Los Angeles, California.Maroon 5 one of the most popular bands of the new millennium.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter">
          <figure><img src="images/robert.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>personal finance by robert kiyoski</h2>
              <p>Robert Toru Kiyosaki is an American businessman and author. Kiyosaki is the founder of Rich Global LLC and the Rich Dad Company, a private financial education company.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
        <article class="one_quarter lastbox">
          <figure><img src="images/elonmusk.jpg" width="215" height="140" alt="">
            <figcaption>
              <h2>A talk about entrepreneurship by elon musk</h2>
              <p>Elon Reeve Musk FRS is a business magnate, industrial designer, and engineer. He is the founder, CEO, CTO, and chief designer of SpaceX; early investor, CEO, and product architect of Tesla, Inc.</p>
              <footer class="more"><a href="events.html">Read More &raquo;</a></footer>
            </figcaption>
          </figure>
        </article>
      </section>
      <!-- / One Quarter -->
    </div>
    <!-- / content body -->
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="#">SpotLight Events</a></p>
  </footer>
</div>
</body>
</html>
