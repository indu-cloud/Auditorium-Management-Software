

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>SpotLight Events</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.37.1" />
	<link rel="stylesheet" href="styles/layout.css" type="text/css">
</head>

<body>
	
	
	<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">SpotLight Events</a></h1>
      <h2>Make Your Event Beautiful</h2>
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>   
         <li><a href="events.html">Events</a></li>     
        <li><a href="login.php?variableName=.">Login</a></li>       
        <li><a href="register.php?variableName=.">Register</a></li>
        <li class="last"><a href="#">About Us</a></li>
      </ul>
    </nav>
  </header>
</div>
	<br>
	<br>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/event1.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Book Launching Ceremony</h4>
                        <p class="card-text">A book launching ceremony for the book written by one of the former commanders of the Navy, Admiral (Retd) Dr. Jayantha Colombage RSP VSV usp reds psc PhD on “Asymmetric Warfare at Sea” was held at 0900 am on 08th December 2016 at General Sir John Kotelawala Defence University. Admiral (Retd) Dr. Jayantha Colombage is the first ever PhD degree holder produced by KDU, and the above book is based on his PhD thesis.Senior Professor Carlo Fonseka, president of the Sri Lanka Medical Council graced the occasion as the Chief Guest; many distinguished guests and the senior officers of Tri Services also participated in this event</p>
						<br>
						<footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/barat1.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Pavithra Bhat's Bharatanatyam</h4>
                        <p class="card-text">Pavitra Bhat (Bharatanatyam)Catch the extremely dynamic and phenomenal Bharatanatyam young maestro Pavitra Bhat take the stage on fire with his poise and abhinaya coupled with top-notch skills on his feet, posture and hands. Kalasagar awards are given in honour of the artistes in the field of Kathakali - Vesham, Music, Chenda, Maddalam and Chutty as well as Bharatanatyam, Mohiniattam, Kuchipudi, Ottenthullal, Chakyarkoothu Vesham, Music, Chenda, Maddalam and Chutty as well as Bharatanatyam, Mohiniattam, Kuchipudi, Ottenthullal, Chakyarkoothu</p>
						<footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/comedy.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">StandUp Comedy by Viva Harsha</h4>
                        <p class="card-text">Who doesn't enjoy a good laugh? You'll find the latest shows by the best Indian comedians - Zakir Khan, Kanan Gill, Biswa Kalyan Rath, Kenny Sebastian, Comicstaan finalists (Nishant Suri, Rahul Dua & others) and more, on Paytm Insider. Catch them doing tours of their specials, trying new material, hosting an open mic, and more. Catch the big names of comedy at Headliners and LOLStars; or shows to see up-and-coming comics enthrall audiences, and open mic events where you'll see and cheer on fresh talent! International legends like Russel Peters, Eddie Izzard & Bill Burr have ticketed here in the past</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/robin1.png" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Robin Sharma's Speech</h4>
                        <p class="card-text">Robin Sharma is a Canadian writer, best known for his The Monk Who Sold His Ferrari book series. Sharma worked as a litigation lawyer until age 25, when he self-published MegaLiving, a book on stress management and spirituality.Robin Sharma was born on June 16, 1964, to Indian (Kashmiri) parents Shiv Sharma and Shashi Sharma, in Uganda. His family moved to Canada when he was a year old. ... Sharma is a lawyer by qualification. He attended the 'Schulich School of Law' at the 'Dalhousie University.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/shreya.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Music Concert By Shreya Goshal</h4>
                        <p class="card-text">Shreya Ghoshal (born 12 March 1984) is an Indian playback singer, songwriter, composer and music producer. She has received four National Film Awards, four Kerala State Film Awards, two Tamil Nadu State Film Awards, seven Filmfare Awards and ten Filmfare Awards South. She has recorded songs for films and albums in various Indian languages and has established herself as a leading playback singer of Indian cinema.

Ghoshal aspired to become a playback singer from an early age. At the age of four, she started learning music. At the age of six, she started her formal training in classical music. At the age of sixteen, she was noticed by the mother of film-maker Sanjay Leela Bhansali when she entered and won the television singing reality show Sa Re Ga Ma.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/sunrisers.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Cheer Your Favourite Sports Team On!</h4>
                        <p class="card-text">The Sunrisers Hyderabad (stylised as SunRisers Hyderabad, abbr. SRH) are a franchise cricket team based in Hyderabad, Telangana, India, that plays in the Indian Premier League (IPL).[3] The franchise is owned by Kalanithi Maran of the Sun TV Network and was founded in 2012 after the Hyderabad-based Deccan Chargers were terminated by the IPL.[4] The team is currently captained by David Warner and coached by Trevor Bayliss.[5] Their primary home ground is the Rajiv Gandhi International Cricket Stadium, Hyderabad, which has capacity of 55,000.[6]
						The team made their first IPL appearance in 2013, where they reached the playoffs, eventually finishing in fourth place.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/magic.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Magic Show By Christopher</h4>
                        <p class="card-text">The power of apparently influencing events by using mysterious or supernatural forces.Magic is the application of beliefs, rituals or actions employed in the belief that they can subdue or manipulate natural or supernatural beings and forces. It is a category into which have been placed various beliefs and practices sometimes considered separate from both religion and science.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/bts.png" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Dance show by BTS</h4>
                        <p class="card-text">Hailing from South Korea, BTS is now the biggest boy band in the world, topping charts and setting records as they continue on their current world tour. Since their debut in 2013, the seven member group — which consists of RM, Jin, Suga, J-Hope, Jimin, V and Jung Kook — have grown beyond the bounds of traditional K-pop acts, making a splash everywhere from Chile to California. Their devoted followers, styled as “ARMY,” have kept them trending on social media at most public appearances, while their musical releases, like this summer’s “Idol,” have broken records on YouTube and international and domestic charts.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/beatbox.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Beat Box Performance</h4>
                        <p class="card-text">Beatboxing (also beat boxing or boxing) is a form of vocal percussion primarily involving the art of mimicking drum machines (typically a TR-808), using one's mouth, lips, tongue, and voice.[1] It may also involve vocal imitation of turntablism, and other musical instruments. Beatboxing today is connected with hip-hop culture, often referred to as "the fifth element" of hip-hop, although it is not limited to hip-hop music.[2][3] The term "beatboxing" is sometimes used to refer to vocal percussion in general.The Internet has played a large part in the popularity of modern beatboxing. </p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/tedx.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">TEDx Event</h4>
                        <p class="card-text">A TEDx event is a local gathering where live TED-like talks and performances are shared with the community. TEDx events are fully planned and coordinated independently, on a community-by-community basis. The content and design of each TEDx event is unique and developed independently, but all of them have features in common.A suite of short, carefully prepared talks, demonstrations and performances that are idea-focused, and cover a wide range of subjects to foster learning, inspiration and wonder – and provoke conversations that matter.

</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/vinci.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Meet Da Vinci</h4>
                        <p class="card-text">Mona Lisa, also known as La Gioconda, is the wife of Francesco del Giocondo. ... It is a visual representation of the idea of happiness suggested by the word "gioconda" in Italian. Leonardo made this notion of happiness the central motif of the portrait: it is this notion that makes the work such an ideal.The Mona Lisa is a half-length portrait painting by Italian artist Leonardo da Vinci.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/piano.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Piano Concert By Sizuka</h4>
                        <p class="card-text">A piano concerto is a type of concerto, a solo composition in the classical music genre which is composed for a piano player, which is typically accompanied by an orchestra or other large ensemble. Piano concertos are typically virtuoso showpieces which require an advanced level of technique on the instrument, including melodic lines interspersed with rapid scales, arpeggios, chords, complex contrapuntal parts and other challenging material. When piano concertos are performed by a professional concert pianist, a large grand piano is almost always used, as the grand piano has a fuller tone and more projection than an upright piano. </p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/marron.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Maroon 5 Concert</h4>
                        <p class="card-text">Maroon 5 is an American pop rock band from Los Angeles, California.[1][2] It currently consists of lead vocalist Adam Levine, keyboardist and rhythm guitarist Jesse Carmichael, lead guitarist James Valentine, drummer Matt Flynn, keyboardist PJ Morton and multi-instrumentalist Sam Farrar. Original members Levine, Carmichael, bassist Mickey Madden, and drummer Ryan Dusick first came together as Kara's Flowers in 1994, while they were still in high school.
                                             After self-releasing their independent album We Like Digging?, the band signed to Reprise Records and released the album The Fourth World in 1997.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/robert.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Personl Finance By Robert Kiyosaki</h4>
                        <p class="card-text">Kiyosaki's financial and business teachings focus on what he calls "financial education": generating passive income by focusing on business and investment opportunities, such as real estate investments, businesses, stocks and commodities, with the goal of being able to support oneself by such investments alone and thus achieving true financial independence. He has a series of authors and other "experts" that he often cites as "Rich Dad Advisors" on real estate investing, financial planning, and avoiding taxes.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	<div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="img-square-wrapper">
                        <img class="image" src="images/elonmusk.jpg" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">A Talk on Entreprenuership By ElonMusk</h4>
                        <p class="card-text">South African entrepreneur Elon Musk is known for founding Tesla Motors and SpaceX, which launched a landmark commercial spacecraft in 2012.Elon Musk is a South African-born American entrepreneur and businessman who founded X.com in 1999 (which later became PayPal), SpaceX in 2002 and Tesla Motors in 2003. Musk became a multimillionaire in his late 20s when he sold his start-up company, Zip2, to a division of Compaq Computers.</p>
                        <footer class="more"><a href="event_reg.php?variableName=.">Book Now &raquo;</a></footer>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
	
	<br><br><br><br><br><br><br><br>
	
	
</body>

</html>
