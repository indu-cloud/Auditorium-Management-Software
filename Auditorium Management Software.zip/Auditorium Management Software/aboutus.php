<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>SpotLight Events</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<!--[if lt IE 9]><script src="scripts/html5shiv.js"></script><![endif]-->
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="#">SpotLight Events</a></h1>
      <h2>Make Your Event Beautiful</h2>
    </div>
    <nav>
      <ul>
        <li><a href="index.php?variableName=.">Home</a></li>
        <li><a href="events.php?variableName=.">Events</a></li>
        <li><a href="login.php?variableName=.">Login</a></li>
        <li><a href="register.php?variableName=.">Register</a>        
        <li class="last"><a href="aboutus.php?variableName=.">About Us</a></li>
      </ul>
    </nav>
  </header>
<section id="slider" class="image1">
      <figure><img src="images/audit.jpg" alt="">
        <figcaption>
<div class="text">

<p>SpotLight Events, a unit of the Bharatiya Kala Kendra Trust, is the most prestigious Theatre Hall of Delhi. The 632 seater Auditorium has been a host to some of the best National and International Theatrical, Dance and Musical Performances. The Auditorium building is an elegant structure with aesthetically designed Public Areas, Main Hall, Green Rooms, etc.The Auditorium is strategically located in the Mandi House area of New Delhi at 1, Copernicus Marg. Mandi House is well known as the cultural hub of the Capital. The Auditorium is well connected by Bus services as well as the Delhi Metro which has its station just 5 minutes walking distance from the Hall.s.The Auditorium has one of the finest stages in the City of Delhi with a width of 15 meters and a depth of 14 meters. The Auditorium stage is ideal for demanding theatrical performances. To enable quick change of scenes and sets as well as elaborate lighting design, the stage is equipped with 21 flying bars with an upper height of over 14 meters.The Auditorium has excellent acoustics. It is furthermore equipped with a professional quality sound system using JBL Speakers, Crown Amplifiers and a 32 Channel Soundcraft Mixer. The Auditorium also has its own sophisticated stage lighting with a large variety of professional lights such as Pars, Profiles, Victories, etc., which are connected through a Computerized Soft Patching System to a 48 channel, zero 88, Bullfrog Control Panel.The Auditorium has a direct inward dialing telephone system to handle customer queries as well as a mobile communication system to enable interconnection between the stage and the control room. In order to enhance security, the Auditorium has an elaborate CCTV System.The Auditorium is proud to be considered as one of the finest Halls in India for presentation of prestigious performances</p>
<p>For 130 years, the Auditorium Theatre has evolved. While the theatre’s programming has adapted and grown, it has always remained dedicated to providing the highest quality of artistic experiences while preserving the storied principles upon which it was founded.

Former Presidents Theodore Roosevelt and William McKinley gave speeches on the same stage where, years later, incandescent musicians such as Jimi Hendrix, The Doors, Aretha Franklin, and Elton John would perform. Stevie Wonder and Ray Charles captivated audiences in the same space where Les Misérables and Phantom of the Opera would play to sold-out crowds. From Frank Sinatra to Itzhak Perlman, Isadora Duncan to The Royal Ballet, The Beach Boys to Booker T. Washington, the Auditorium has welcomed legends to its stage.

Today, the Auditorium Theatre presents programming that reflects the diversity and the complexity of the city of Chicago and the world around us, from inspiring dance companies like Alvin Ailey American Dance Theater, American Ballet Theatre, and Ballet Folklórico de México to uplifting performances including Too Hot to Handel, Kathleen Battle, and Bernadette Peters and the Boston Pops. Chicago’s best local dance companies, such as Giordano Dance Chicago, Hubbard Street Dance Chicago, and Ensemble Español Spanish Dance Theater, are showcased in the “Made in Chicago” Dance Series. The National Geographic Live Speaker Series, launched in the 2018-19 season, brings audacious explorers to the theatre’s stage to share their stories, videos, and photographs. The theatre also hosts rock stars like Neil Young, David Byrne, and David Gilmour.</p>
</div>

<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="#">SpotLight Events</a></p>
  </footer>
</div>
</body>
</html>
